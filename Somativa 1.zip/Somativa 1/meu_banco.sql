/* S1L: */

CREATE TABLE Clientes (
    id_cliente INT PRIMARY KEY,
    nome VARCHAR(100),
    telefone VARCHAR(20),
    endere�o VARCHAR(200)
);

CREATE TABLE Sanduiche (
    id_sanduiche INT PRIMARY KEY,
    nome VARCHAR(100),
    descricao VARCHAR(200),
    preco DECIMAL(10,2)
);

CREATE TABLE Pedidos (
    id_pedido INT PRIMARY KEY,
    data_pedido DATE,
    id_cliente INT,
    status INT,
    id_entregador INT
);

CREATE TABLE ItensPedido (
    id_item INT PRIMARY KEY,
    id_pedido INT,
    id_sanduiche INT,
    quantidade INT,
    subtotal DECIMAL(10,2)
);

CREATE TABLE Entregador (
    id_entregador INT PRIMARY KEY,
    nome VARCHAR(100),
    telefone_celular INT
);
 
ALTER TABLE Pedidos ADD CONSTRAINT FK_Pedidos_2
    FOREIGN KEY (id_cliente???, id_entregador???)
    REFERENCES ??? (???);
 
ALTER TABLE ItensPedido ADD CONSTRAINT FK_ItensPedido_2
    FOREIGN KEY (id_pedido???, id_sanduiche???)
    REFERENCES ??? (???);
 
ALTER TABLE Entregador ADD CONSTRAINT FK_Entregador_2
    FOREIGN KEY (telefone_celular)
    REFERENCES Pedidos (id_pedido);